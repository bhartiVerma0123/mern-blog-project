import React from 'react'

export const Footer = () => {
  return (
    <footer>
      <p>Mern Blog Project - Developd By Our Team </p>
    </footer>
  )
}
