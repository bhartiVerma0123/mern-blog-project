import React from "react";
import { Header } from "./Header";
import { Footer } from "./Footer";
import { Banner } from "./Banner";
import { Blogs } from "./Blogs";

export const Layout = () => {
  return (
    <>
      <Header />
      <Banner />
      <section id="blog-content">
        <div className="container">
          <h1>Latest Blogs</h1>
          <div className="blog-box">
            <div className="blog-left-data">
              <div className="blog-data">
                <h2 className="blog_title">Blog Title</h2>
                <p className="blog_description">Lorem ipsum dolor sit amet consectetur adipisicing elit. Itaque pariatur quis cumque odio alias sed velit rerum sequi quas debitis magni iusto voluptas error, sapiente cupiditate provident dolor? Placeat, odio! Lorem ipsum dolor sit amet consectetur adipisicing elit. Itaque pariatur quis cumque odio alias sed velit rerum sequi quas debitis magni iusto voluptas error</p>
              </div>
              <div className="blog-data">
                <h2 className="blog_title">Blog Title 2</h2>
                <p className="blog_description">Lorem ipsum dolor sit amet consectetur adipisicing elit. Itaque pariatur quis cumque odio alias sed velit rerum sequi quas debitis magni iusto voluptas error, sapiente cupiditate provident dolor? Placeat, odio! Lorem ipsum dolor sit amet consectetur adipisicing elit. Itaque pariatur quis cumque odio alias sed velit rerum sequi quas debitis magni iusto voluptas error</p>
              </div>
              <div className="blog-data">
                <h2 className="blog_title">Blog Title 3</h2>
                <p className="blog_description">Lorem ipsum dolor sit amet consectetur adipisicing elit. Itaque pariatur quis cumque odio alias sed velit rerum sequi quas debitis magni iusto voluptas error, sapiente cupiditate provident dolor? Placeat, odio! Lorem ipsum dolor sit amet consectetur adipisicing elit. Itaque pariatur quis cumque odio alias sed velit rerum sequi quas debitis magni iusto voluptas error</p>
              </div>
              <div className="view-more"> 
                <a href="">View All Blogs</a>
              </div>
            </div>
            <div className="blog-right-data">
              <div className="right-blog-box">
                <h4>Blog Title 1</h4>
              </div>
              <div className="right-blog-box">
                <h4>Blog Title 2</h4>
              </div>
              <div className="right-blog-box">
                <h4>Blog Title 3</h4>
              </div>
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </>
  );
};
