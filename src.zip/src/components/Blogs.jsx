import React from 'react'

export const Blogs = () => {
  return (
    <div>Blogs</div>
  )
}
