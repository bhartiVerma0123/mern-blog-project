import React from 'react'

export const Banner = () => {
  return (
    <section id='banner'>
      <h1>Blog Management System</h1>
    </section>
  )
}
